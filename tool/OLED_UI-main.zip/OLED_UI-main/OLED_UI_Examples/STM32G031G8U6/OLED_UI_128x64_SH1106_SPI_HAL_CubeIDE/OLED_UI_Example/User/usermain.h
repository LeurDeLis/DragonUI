/*
 * usermain.h
 *
 *  Created on: Nov 27, 2024
 *      Author: tonny
 */

#ifndef USERMAIN_H_
#define USERMAIN_H_
#include "stm32g0xx_hal.h"

extern TIM_HandleTypeDef htim16;

void usermain();

#endif /* USERMAIN_H_ */
